<?php
/* Practical 10: server-side access control. Anyone without a
   valid faculty login is redirected before any HTML is sent. */
declare(strict_types=1);
require_once __DIR__ . '/../php/auth.php';
$user = require_role('faculty', 'faculty-login.html');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="StudentHub Faculty Dashboard">
  <title>Faculty Dashboard | StudentHub</title>

  <link rel="stylesheet" href="../css/style.css">
</head>

<body>

    <!-- Practical 4: restore saved theme before first paint -->
    <script>try{var s=localStorage.getItem("studentHubTheme");if(s==="dark"){document.body.classList.add("dark-mode");}}catch(e){}</script>

  <!-- Skip Link -->
  <a class="skip-link" href="#main">Skip to main content</a>


  <!-- Header -->
  <header class="site-header">
    <div class="container">

      <div class="brand">
        <img src="../images/logo.png" alt="StudentHub logo">
        <h1>StudentHub</h1>
      </div>


     <button type="button" class="menu-toggle" id="menuToggle" aria-label="Open navigation menu" aria-expanded="false" aria-controls="mainNav">☰</button>
     <button type="button" class="theme-toggle" id="themeToggle" aria-label="Switch to dark mode" title="Switch to dark mode"><span class="theme-icon" aria-hidden="true">🌙</span><span class="theme-label visually-hidden">Dark mode</span></button>

     <nav id="mainNav" aria-label="Faculty navigation">

    <ul class="nav-list">

        <li>
            <a href="faculty-dashboard.php" aria-current="page">
                Dashboard
            </a>
        </li>

        <li>
            <a href="faculty-profile.html">
                Profile
            </a>
        </li>

        <li class="nav-item-drop">
            <a href="students.html" class="nav-drop-link">
                Students
                <span class="nav-drop-caret" aria-hidden="true">&#9662;</span>
            </a>
            <ul class="nav-submenu">
                <li>
                    <a href="student-manage.php">Student Manage (P11)</a>
                </li>
                <li>
                    <a href="students-ajax.php">Live List (P13)</a>
                </li>
                <li>
                    <a href="students.html">Public List (P6)</a>
                </li>
                <li>
                    <span class="submenu-note">Practical 13 = no page reload</span>
                </li>
            </ul>
        </li>

        <li>
            <a href="event-manage.php">
                Events
            </a>
        </li>

        <li>
            <a href="../php/logout.php">
                Logout
            </a>
        </li>

    </ul>

</nav>
    </div>
  </header>


  <!-- Main -->
  <main id="main">
    <?php if (isset($_GET['denied'])): ?>
    <div class="container">
        <p class="data-status data-error" role="alert">Access denied: that page is for a different role.</p>
    </div>
    <?php endif; ?>

    <!-- Faculty Hero -->
    <section class="dashboard-hero faculty-dashboard-hero">
      <div class="container">

        <p class="eyebrow">FACULTY PORTAL</p>

        <h2>Welcome Back, <?php echo htmlspecialchars((string)($user['name'] ?? 'Faculty'), ENT_QUOTES, 'UTF-8'); ?>!</h2>

        <p>
          Manage student information, campus events and
          announcements from your faculty dashboard.
        </p>

      </div>
    </section>


    <!-- Faculty Information -->
    <section class="dashboard-section">
      <div class="container">

        <div class="section-heading">
          <p class="eyebrow">FACULTY INFORMATION</p>
          <h2>Faculty Overview</h2>
          <p>
            Your faculty information is shown below.
          </p>
        </div>

        <div class="dashboard-info-grid">

          <article class="dashboard-info-card">
            <span class="dashboard-icon" aria-hidden="true">👨‍🏫</span>

            <div>
              <h3>Faculty Name</h3>
              <p>Dr. Faculty Name</p>
            </div>
          </article>


          <article class="dashboard-info-card">
            <span class="dashboard-icon" aria-hidden="true">🆔</span>

            <div>
              <h3>Faculty ID</h3>
              <p>FAC2026001</p>
            </div>
          </article>


          <article class="dashboard-info-card">
            <span class="dashboard-icon" aria-hidden="true">🏫</span>

            <div>
              <h3>Department</h3>
              <p>Computer Applications</p>
            </div>
          </article>


          <article class="dashboard-info-card">
            <span class="dashboard-icon" aria-hidden="true">🎓</span>

            <div>
              <h3>Students</h3>
              <p>120 Students</p>
            </div>
          </article>

        </div>

      </div>
    </section>


    <!-- Faculty Statistics -->
    <section class="dashboard-section dashboard-section-alt">
      <div class="container">

        <div class="section-heading">
          <p class="eyebrow">OVERVIEW</p>
          <h2>Dashboard Statistics</h2>
        </div>

        <div class="faculty-stat-grid">

          <article class="faculty-stat-card">
            <span class="faculty-stat-icon" aria-hidden="true">👨‍🎓</span>
            <strong>120</strong>
            <h3>Total Students</h3>
            <p>Students in your department</p>
          </article>


          <article class="faculty-stat-card">
            <span class="faculty-stat-icon" aria-hidden="true">📅</span>
            <strong>3</strong>
            <h3>Upcoming Events</h3>
            <p>Events scheduled</p>
          </article>


          <article class="faculty-stat-card">
            <span class="faculty-stat-icon" aria-hidden="true">📢</span>
            <strong>4</strong>
            <h3>Announcements</h3>
            <p>Published announcements</p>
          </article>


          <article class="faculty-stat-card">
            <span class="faculty-stat-icon" aria-hidden="true">💬</span>
            <strong>8</strong>
            <h3>Student Feedback</h3>
            <p>Recent feedback received</p>
          </article>

        </div>

      </div>
    </section>


    <!-- Upcoming Events -->
    <section class="dashboard-section">
      <div class="container">

        <div class="section-heading">
          <p class="eyebrow">EVENT MANAGEMENT</p>
          <h2>Upcoming Events</h2>
          <p>
            View and manage upcoming campus activities.
          </p>
        </div>

        <div class="dashboard-card-grid">

          <article class="dashboard-card">
            <span class="event-date">15 NOV</span>

            <h3>Cultural Festival</h3>

            <p class="card-location">
              📍 College Auditorium
            </p>

            <p>
              Annual cultural event for students and faculty.
            </p>

            <a href="event-manage.php" class="text-link">
              View Event →
            </a>
          </article>


          <article class="dashboard-card">
            <span class="event-date">20 NOV</span>

            <h3>Technical Workshop</h3>

            <p class="card-location">
              📍 Computer Lab
            </p>

            <p>
              Technical workshop focused on practical skills.
            </p>

            <a href="event-manage.php" class="text-link">
              View Event →
            </a>
          </article>


          <article class="dashboard-card">
            <span class="event-date">05 DEC</span>

            <h3>Sports Day</h3>

            <p class="card-location">
              📍 College Ground
            </p>

            <p>
              Annual sports activities for students.
            </p>

            <a href="event-manage.php" class="text-link">
              View Event →
            </a>
          </article>

        </div>

      </div>
    </section>


    <!-- Recent Announcements -->
    <section class="dashboard-section dashboard-section-alt">
      <div class="container">

        <div class="section-heading">
          <p class="eyebrow">COMMUNICATION</p>
          <h2>Recent Announcements</h2>
          <p>
            Keep track of announcements shared with students.
          </p>
        </div>

        <div class="announcement-dashboard-list">

          <article class="announcement-dashboard-card">
            <span class="announcement-tag">GENERAL</span>

            <div>
              <h3>Welcome to StudentHub</h3>

              <p>
                StudentHub is now available for students and faculty.
              </p>

              <span class="announcement-date-small">
                10 November 2026
              </span>
            </div>
          </article>


          <article class="announcement-dashboard-card">
            <span class="announcement-tag">EVENTS</span>

            <div>
              <h3>Cultural Festival</h3>

              <p>
                Students can participate in the upcoming
                Cultural Festival.
              </p>

              <span class="announcement-date-small">
                15 November 2026
              </span>
            </div>
          </article>


          <article class="announcement-dashboard-card">
            <span class="announcement-tag">ACADEMIC</span>

            <div>
              <h3>Technical Workshop</h3>

              <p>
                Faculty and students are invited to join
                the technical workshop.
              </p>

              <span class="announcement-date-small">
                20 November 2026
              </span>
            </div>
          </article>

        </div>

        <div class="dashboard-center-button">
          <a href="announcements.html" class="btn btn-outline">
            Manage Announcements
          </a>
        </div>

      </div>
    </section>


    <!-- Faculty Quick Links -->
    <section class="dashboard-section">
      <div class="container">

        <div class="section-heading">
          <p class="eyebrow">QUICK ACCESS</p>
          <h2>Faculty Quick Links</h2>
        </div>

        <div class="quick-links">

          <a href="faculty-profile.html" class="quick-link">
            <span>👤</span>
            <strong>My Profile</strong>
            <small>View faculty profile</small>
          </a>


          <a href="students.html" class="quick-link">
            <span>👨‍🎓</span>
            <strong>Students</strong>
            <small>View student information</small>
          </a>

          <a href="event-manage.php" class="quick-link">
            <span>📅</span>
            <strong>Events</strong>
            <small>Create and manage events</small>
          </a>


          <a href="student-manage.php" class="quick-link">
            <span>📝</span>
            <strong>Manage Students</strong>
            <small>Add, edit and remove records</small>
          </a>


          <a href="students-ajax.php" class="quick-link">
            <span>⚡</span>
            <strong>Live Student List</strong>
            <small>No-reload AJAX version</small>
          </a>


          <a href="event-manage.php" class="quick-link">
            <span>📅</span>
            <strong>Events</strong>
            <small>Manage campus events</small>
          </a>


          <a href="announcements.html" class="quick-link">
            <span>📢</span>
            <strong>Announcements</strong>
            <small>Manage announcements</small>
          </a>

        </div>

      </div>
    </section>


    <!-- Faculty CTA -->
    <section class="dashboard-cta">
      <div class="container">

        <h2>Manage StudentHub</h2>

        <p>
          Keep students informed, connected and engaged
          with campus activities.
        </p>

        <div class="cta-buttons">

          <a href="event-manage.php" class="btn">
            Manage Events
          </a>

          <a href="announcements.html" class="btn btn-outline">
            Announcements
          </a>

        </div>

      </div>
    </section>

  </main>


  <!-- Footer -->
  <footer class="site-footer">
    <div class="container">

      <div class="footer-content">

        <div class="footer-column">
          <h2>StudentHub</h2>
          <p>
            Your campus. Your community. Your hub.
          </p>
        </div>


        <div class="footer-column">
          <h3>Faculty</h3>

          <ul>
            <li>
              <a href="faculty-dashboard.php">
                Dashboard
              </a>
            </li>

            <li>
              <a href="faculty-profile.html">
                Profile
              </a>
            </li>

            <li>
              <a href="students.html">
                Students
              </a>
            </li>

            <li>
              <a href="event-manage.php">
                Events
              </a>
            </li>
          </ul>

        </div>


        <div class="footer-column">
          <h3>Management</h3>

          <ul>
            <li>
              <a href="announcements.html">
                Announcements
              </a>
            </li>

            <li>
              <a href="contact.html">
                Contact
              </a>
            </li>

            <li>
              <a href="faq.html">
                FAQ
              </a>
            </li>
          </ul>

        </div>

      </div>


      <div class="footer-bottom">
        <p>
          &copy; 2026 StudentHub. All rights reserved.
        </p>
      </div>

    </div>
  </footer>

  <script src="../js/script.js"></script>
</body>
</html>