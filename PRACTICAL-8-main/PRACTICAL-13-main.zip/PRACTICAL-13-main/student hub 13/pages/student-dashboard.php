<?php
/* Practical 10: server-side access control. Anyone without a
   valid student login is redirected before any HTML is sent. */
declare(strict_types=1);
require_once __DIR__ . '/../php/auth.php';
$user = require_role('student', 'student-login.html');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="StudentHub student dashboard">

    <title>Student Dashboard | StudentHub</title>

    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

    <!-- Practical 4: restore saved theme before first paint -->
    <script>try{var s=localStorage.getItem("studentHubTheme");if(s==="dark"){document.body.classList.add("dark-mode");}}catch(e){}</script>

    <a href="#main" class="skip-link">Skip to main content</a>

<header class="site-header">

    <div class="container">

        <div class="brand">
            <img src="../images/logo.png" alt="StudentHub logo">
            <h1>StudentHub</h1>
        </div>

        <!-- Student Navigation -->

        <button type="button" class="menu-toggle" id="menuToggle" aria-label="Open navigation menu" aria-expanded="false" aria-controls="mainNav">☰</button>
        <button type="button" class="theme-toggle" id="themeToggle" aria-label="Switch to dark mode" title="Switch to dark mode"><span class="theme-icon" aria-hidden="true">🌙</span><span class="theme-label visually-hidden">Dark mode</span></button>

        <nav id="mainNav" aria-label="Student navigation">

            <ul class="nav-list">

                <li>
                    <a href="student-dashboard.php" aria-current="page">
                        Dashboard
                    </a>
                </li>

                <li>
                    <a href="profile.html">
                        Profile
                    </a>
                </li>

                <li>
                    <a href="my-details.html">
                        My Details
                    </a>
                </li>

                <li>
                    <a href="resources.html">
                        Resources
                    </a>
                </li>

                <li>
                    <a href="../php/logout.php">
                        Logout
                    </a>
                </li>

            </ul>

        </nav>

    </div>

</header>


<main id="main">
    <?php if (isset($_GET['denied'])): ?>
    <div class="container">
        <p class="data-status data-error" role="alert">Access denied: that page is for a different role.</p>
    </div>
    <?php endif; ?>

    <!-- Dashboard Hero -->
    <section class="dashboard-hero">

        <div class="container">

            <h2>Welcome, <?php echo htmlspecialchars((string)($user['name'] ?? 'Student'), ENT_QUOTES, 'UTF-8'); ?>!</h2>

            <p>
                Manage your student information and access StudentHub services.
            </p>

        </div>

    </section>


    <!-- Student Information -->
    <section class="section dashboard-section">

        <div class="container">

            <h2>Student Information</h2>

            <div class="dashboard-info-grid">

                <div class="card">
                    <h3>Student Name</h3>
                    <p>Dhruv Varmora</p>
                </div>

                <div class="card">
                    <h3>Student ID</h3>
                    <p>STU2026001</p>
                </div>

                <div class="card">
                    <h3>Course</h3>
                    <p>BCA</p>
                </div>

                <div class="card">
                    <h3>Semester</h3>
                    <p>Semester 3</p>
                </div>

            </div>

        </div>

    </section>


    <!-- Upcoming Events -->
    <section class="section dashboard-section">

        <div class="container">

            <h2>Upcoming Events</h2>

            <div class="dashboard-card-grid">

                <article class="card">

                    <h3>Cultural Festival</h3>

                    <p>
                        <strong>Date:</strong>
                        15 November 2026
                    </p>

                    <p>
                        Enjoy cultural performances, activities
                        and student celebrations.
                    </p>

                </article>


                <article class="card">

                    <h3>Technical Workshop</h3>

                    <p>
                        <strong>Date:</strong>
                        20 November 2026
                    </p>

                    <p>
                        Learn new technical skills through
                        an interactive workshop.
                    </p>

                </article>


                <article class="card">

                    <h3>Sports Day</h3>

                    <p>
                        <strong>Date:</strong>
                        5 December 2026
                    </p>

                    <p>
                        Participate in different sports
                        and campus activities.
                    </p>

                </article>

            </div>

        </div>

    </section>


    <!-- Latest Announcements -->
    <section class="section dashboard-section">

        <div class="container">

            <h2>Latest Announcements</h2>

            <div class="announcement-dashboard-list">

                <article class="card">

                    <h3>Welcome to StudentHub</h3>

                    <p>
                        Welcome to the StudentHub student portal.
                    </p>

                    <small>
                        10 November 2026
                    </small>

                </article>


                <article class="card">

                    <h3>Cultural Festival</h3>

                    <p>
                        Cultural Festival will be held on
                        15 November 2026.
                    </p>

                    <small>
                        10 November 2026
                    </small>

                </article>


                <article class="card">

                    <h3>Technical Workshop</h3>

                    <p>
                        A technical workshop will be conducted
                        on 20 November 2026.
                    </p>

                    <small>
                        10 November 2026
                    </small>

                </article>

            </div>

        </div>

    </section>


    <!-- Student Resources -->
    <section class="section dashboard-section">

        <div class="container">

            <h2>Student Resources</h2>

            <div class="dashboard-card-grid">

                <article class="card">

                    <h3>Study Materials</h3>

                    <p>
                        Access useful academic study materials
                        and learning resources.
                    </p>

                    <a href="resources.html" class="btn">
                        View Resources
                    </a>

                </article>


                <article class="card">

                    <h3>Assignments</h3>

                    <p>
                        Keep track of your academic assignments
                        and learning activities.
                    </p>

                    <a href="resources.html" class="btn">
                        View Resources
                    </a>

                </article>


                <article class="card">

                    <h3>Student Support</h3>

                    <p>
                        Get help and support through the
                        StudentHub support services.
                    </p>

                    <a href="resources.html" class="btn">
                        Get Support
                    </a>

                </article>

            </div>

        </div>

    </section>


    <!-- Quick Links -->
    <section class="section dashboard-section">

        <div class="container">

            <h2>Quick Links</h2>

            <div class="quick-links">

                <a href="profile.html" class="btn">
                    My Profile
                </a>

                <a href="my-details.html" class="btn">
                    My Details
                </a>

                <a href="resources.html" class="btn">
                    Resources
                </a>

            </div>

        </div>

    </section>


    <!-- Help Section -->
    <section class="section dashboard-cta">

        <div class="container">

            <h2>Need Help?</h2>

            <p>
                If you need assistance, contact StudentHub
                support or check the available resources.
            </p>

            <a href="contact.html" class="btn">
                Contact Support
            </a>

        </div>

    </section>

</main>


<!-- Footer -->
<footer class="site-footer">

    <div class="container">

        <p>
            &copy; 2026 StudentHub. All rights reserved.
        </p>

    </div>

</footer>
<script src="../js/script.js"></script>
</body>

</html>